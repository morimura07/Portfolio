"use client"

import { useState } from "react"
import PageLayout from "@/components/PageLayout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github, Blocks, Database, Smartphone, Globe, Brain, Shield } from "lucide-react"

export default function ProjectsPage() {
  const [activeFilter, setActiveFilter] = useState("All")

  const projects = [
    {
      title: "DeFi Trading Platform",
      description:
        "A comprehensive decentralized finance platform with automated market making, yield farming, and governance features.",
      category: "Blockchain",
      icon: Blocks,
      color: "#8b5cf6",
      technologies: ["Solidity", "React", "Web3.js", "Node.js", "PostgreSQL"],
      features: ["Smart Contracts", "AMM Protocol", "Yield Farming", "DAO Governance"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Real-time Analytics Dashboard",
      description:
        "Enterprise-grade analytics platform processing millions of events per second with real-time visualizations.",
      category: "Full-Stack",
      icon: Database,
      color: "#10b981",
      technologies: ["React", "Node.js", "Redis", "PostgreSQL", "Docker"],
      features: ["Real-time Processing", "Custom Visualizations", "API Integration", "Scalable Architecture"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Cross-platform Mobile App",
      description: "Social networking app with real-time messaging, media sharing, and location-based features.",
      category: "Mobile",
      icon: Smartphone,
      color: "#ec4899",
      technologies: ["React Native", "Firebase", "Node.js", "MongoDB", "AWS"],
      features: ["Real-time Chat", "Media Sharing", "Push Notifications", "Offline Support"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "E-commerce Microservices",
      description:
        "Scalable e-commerce platform built with microservices architecture, handling high-volume transactions.",
      category: "Backend",
      icon: Globe,
      color: "#3b82f6",
      technologies: ["Node.js", "Docker", "Kubernetes", "PostgreSQL", "Redis"],
      features: ["Microservices", "Payment Processing", "Inventory Management", "Order Tracking"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "NFT Marketplace",
      description:
        "Full-featured NFT marketplace with minting, trading, and auction capabilities on multiple blockchains.",
      category: "Blockchain",
      icon: Blocks,
      color: "#8b5cf6",
      technologies: ["Solidity", "Next.js", "IPFS", "Ethers.js", "Tailwind"],
      features: ["Multi-chain Support", "Auction System", "Royalty Management", "Metadata Storage"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "AI-Powered SaaS Platform",
      description: "Machine learning platform providing automated insights and predictions for business intelligence.",
      category: "Full-Stack",
      icon: Brain,
      color: "#10b981",
      technologies: ["Python", "React", "TensorFlow", "FastAPI", "PostgreSQL"],
      features: ["ML Models", "Automated Reports", "API Integration", "Custom Dashboards"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Cryptocurrency Exchange",
      description: "High-performance trading platform with advanced order matching and security features.",
      category: "Blockchain",
      icon: Blocks,
      color: "#8b5cf6",
      technologies: ["Go", "React", "WebSocket", "Redis", "PostgreSQL"],
      features: ["Order Matching", "Real-time Trading", "Multi-asset Support", "Advanced Security"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Cloud Infrastructure Manager",
      description: "DevOps platform for managing cloud resources across multiple providers with automation.",
      category: "Backend",
      icon: Globe,
      color: "#3b82f6",
      technologies: ["Go", "Terraform", "Kubernetes", "AWS", "GCP"],
      features: ["Multi-cloud Support", "Infrastructure as Code", "Auto-scaling", "Cost Optimization"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Healthcare Management System",
      description: "Comprehensive healthcare platform with patient records, scheduling, and telemedicine features.",
      category: "Full-Stack",
      icon: Database,
      color: "#10b981",
      technologies: ["React", "Node.js", "MongoDB", "Socket.io", "AWS"],
      features: ["Patient Records", "Appointment Scheduling", "Video Consultations", "HIPAA Compliant"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "IoT Data Processing Pipeline",
      description: "Real-time data processing system for IoT devices with edge computing capabilities.",
      category: "Backend",
      icon: Database,
      color: "#3b82f6",
      technologies: ["Python", "Apache Kafka", "InfluxDB", "Docker", "Kubernetes"],
      features: ["Real-time Processing", "Edge Computing", "Data Analytics", "Device Management"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Fitness Tracking App",
      description: "Mobile fitness application with workout tracking, nutrition planning, and social features.",
      category: "Mobile",
      icon: Smartphone,
      color: "#ec4899",
      technologies: ["Flutter", "Firebase", "Node.js", "MongoDB", "ML Kit"],
      features: ["Workout Tracking", "Nutrition Planning", "Social Features", "Progress Analytics"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Cybersecurity Dashboard",
      description: "Security monitoring platform with threat detection, incident response, and compliance reporting.",
      category: "Full-Stack",
      icon: Shield,
      color: "#10b981",
      technologies: ["React", "Python", "Elasticsearch", "Kibana", "Docker"],
      features: ["Threat Detection", "Incident Response", "Compliance Reporting", "Real-time Monitoring"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Smart Contract Auditing Tool",
      description: "Automated security analysis tool for smart contracts with vulnerability detection.",
      category: "Blockchain",
      icon: Shield,
      color: "#8b5cf6",
      technologies: ["Python", "Solidity", "React", "Node.js", "Docker"],
      features: ["Vulnerability Detection", "Code Analysis", "Security Reports", "Best Practices"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Video Streaming Platform",
      description: "Scalable video streaming service with live broadcasting and content management features.",
      category: "Full-Stack",
      icon: Globe,
      color: "#10b981",
      technologies: ["React", "Node.js", "FFmpeg", "AWS", "CDN"],
      features: ["Live Streaming", "Video Processing", "Content Management", "Global CDN"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      title: "Augmented Reality Shopping",
      description: "AR-powered mobile shopping experience with virtual try-on and 3D product visualization.",
      category: "Mobile",
      icon: Smartphone,
      color: "#ec4899",
      technologies: ["Unity", "ARCore", "ARKit", "React Native", "Node.js"],
      features: ["Virtual Try-on", "3D Visualization", "AR Shopping", "Social Sharing"],
      github: "https://github.com",
      demo: "https://demo.com",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  const categories = ["All", "Blockchain", "Full-Stack", "Mobile", "Backend"]

  // Filter projects based on active filter
  const filteredProjects =
    activeFilter === "All" ? projects : projects.filter((project) => project.category === activeFilter)

  // Get project count for each category
  const getCategoryCount = (category: string) => {
    if (category === "All") return projects.length
    return projects.filter((project) => project.category === category).length
  }

  return (
    <PageLayout>
      <div className="py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-white mb-6">Featured Projects</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              A showcase of my recent work spanning blockchain development, full-stack applications, and mobile
              solutions.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex justify-center mb-12">
            <div className="flex gap-2 bg-black/30 backdrop-blur-md border border-white/20 rounded-full p-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant="ghost"
                  size="sm"
                  onClick={() => setActiveFilter(category)}
                  className={`rounded-full transition-all duration-300 ${
                    activeFilter === category
                      ? "bg-white/20 text-white shadow-lg"
                      : "text-white/80 hover:text-white hover:bg-white/10"
                  }`}
                >
                  {category}
                  <span className="ml-2 text-xs opacity-70">({getCategoryCount(category)})</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Results Counter */}
          <div className="text-center mb-8">
            <p className="text-gray-400 text-sm">
              Showing {filteredProjects.length} {filteredProjects.length === 1 ? "project" : "projects"}
              {activeFilter !== "All" && (
                <span>
                  {" "}
                  in <span className="text-white font-medium">{activeFilter}</span>
                </span>
              )}
            </p>
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => {
              const Icon = project.icon
              return (
                <Card
                  key={`${project.title}-${index}`}
                  className="bg-black/30 border-white/20 text-white overflow-hidden group hover:bg-black/40 transition-all duration-300 backdrop-blur-sm flex flex-col h-full animate-in fade-in-0 duration-500"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="aspect-video bg-gradient-to-br from-gray-800 to-gray-900 relative overflow-hidden">
                    <img
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300" />
                    <div className="absolute top-4 left-4">
                      <Badge
                        className="bg-black/50 border-current text-white"
                        style={{ borderColor: project.color, color: project.color }}
                      >
                        <Icon size={14} className="mr-1" />
                        {project.category}
                      </Badge>
                    </div>
                  </div>

                  <CardHeader className="flex-shrink-0">
                    <CardTitle className="text-xl">{project.title}</CardTitle>
                    <p className="text-gray-300 text-sm line-clamp-3">{project.description}</p>
                  </CardHeader>

                  <CardContent className="flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-4">
                      {/* Technologies */}
                      <div>
                        <h4 className="text-sm font-medium mb-2 text-gray-300">Technologies</h4>
                        <div className="flex flex-wrap gap-1">
                          {project.technologies.map((tech, techIndex) => (
                            <Badge
                              key={techIndex}
                              variant="outline"
                              className="border-white/30 text-white/90 text-xs bg-white/5"
                            >
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Features */}
                      <div>
                        <h4 className="text-sm font-medium mb-2 text-gray-300">Key Features</h4>
                        <ul className="text-xs text-gray-400 space-y-1">
                          {project.features.map((feature, featureIndex) => (
                            <li key={featureIndex}>• {feature}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Links - Fixed at bottom */}
                    <div className="flex gap-2 pt-4 mt-auto">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-white/30 text-white hover:bg-white/20 flex-1 bg-transparent transition-all duration-300"
                      >
                        <Github size={14} className="mr-1" />
                        Code
                      </Button>
                      <Button
                        size="sm"
                        className="bg-white/20 hover:bg-white/30 text-white flex-1 transition-all duration-300"
                      >
                        <ExternalLink size={14} className="mr-1" />
                        Demo
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* No results message */}
          {filteredProjects.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg mb-4">No projects found in this category.</p>
              <Button
                onClick={() => setActiveFilter("All")}
                className="bg-white/10 hover:bg-white/20 border border-white/20 text-white"
              >
                View All Projects
              </Button>
            </div>
          )}
        </div>
      </div>
    </PageLayout>
  )
}
