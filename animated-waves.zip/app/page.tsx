"use client"

import PageLayout from "@/components/PageLayout"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Code, Database, Blocks } from "lucide-react"

export default function HomePage() {
  return (
    <PageLayout>
      <div className="flex flex-col items-center justify-center min-h-screen text-white px-4 sm:px-8">
        <div className="text-center max-w-4xl">
          {/* Main Title */}
          <div className="mb-6">
            <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">
              David James
            </h1>
            <div className="flex flex-wrap items-center justify-center gap-3 mb-4">
              <div className="flex items-center gap-2 text-blue-300">
                <Code size={20} />
                <span className="text-lg">Full-Stack</span>
              </div>
              <div className="w-1 h-1 bg-white/50 rounded-full"></div>
              <div className="flex items-center gap-2 text-green-300">
                <Database size={20} />
                <span className="text-lg">Backend</span>
              </div>
              <div className="w-1 h-1 bg-white/50 rounded-full"></div>
              <div className="flex items-center gap-2 text-purple-300">
                <Blocks size={20} />
                <span className="text-lg">Blockchain</span>
              </div>
            </div>
          </div>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl text-gray-300 mb-8 leading-relaxed">
            Crafting innovative digital solutions with modern technologies.
            <br />
            Specializing in scalable applications and decentralized systems.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Link href="/projects">
              <Button className="bg-white/10 hover:bg-white/20 border border-white/20 text-white px-6 py-2 text-base rounded-full transition-all duration-300 flex items-center gap-2">
                View My Work
                <ArrowRight size={18} />
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-6 py-2 text-base rounded-full transition-all duration-300 bg-transparent"
              >
                Get In Touch
              </Button>
            </Link>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-6 max-w-lg mx-auto">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-300 mb-1">15+</div>
              <div className="text-gray-400 text-xs">Projects</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-300 mb-1">5+</div>
              <div className="text-gray-400 text-xs">Years Exp</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-300 mb-1">15+</div>
              <div className="text-gray-400 text-xs">Technologies</div>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
