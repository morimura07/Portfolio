"use client"

import PageLayout from "@/components/PageLayout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Send, Github, Linkedin, Twitter } from "lucide-react"

export default function ContactPage() {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "luckydavid0812@gmail.com",
      href: "mailto:luckydavid0812@gmail.com",
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+1 (555) 123-4567",
      href: "tel:+15551234567",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "San Francisco, CA",
      href: "#",
    },
  ]

  const socialLinks = [
    { icon: Github, label: "GitHub", href: "https://github.com", color: "hover:text-gray-300" },
    { icon: Linkedin, label: "LinkedIn", href: "https://linkedin.com", color: "hover:text-blue-400" },
    { icon: Twitter, label: "Twitter", href: "https://twitter.com", color: "hover:text-blue-400" },
  ]

  return (
    <PageLayout>
      <div className="py-32 px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-white mb-6">Get In Touch</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Ready to collaborate on your next project? Let's discuss how we can bring your ideas to life.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl">Send a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">First Name</label>
                      <Input
                        className="bg-white/10 border-white/30 text-white placeholder:text-gray-400"
                        placeholder="John"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Last Name</label>
                      <Input
                        className="bg-white/10 border-white/30 text-white placeholder:text-gray-400"
                        placeholder="Doe"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <Input
                      type="email"
                      className="bg-white/10 border-white/30 text-white placeholder:text-gray-400"
                      placeholder="john@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Subject</label>
                    <Input
                      className="bg-white/10 border-white/30 text-white placeholder:text-gray-400"
                      placeholder="Project Collaboration"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Message</label>
                    <Textarea
                      className="bg-white/10 border-white/30 text-white placeholder:text-gray-400 min-h-[120px]"
                      placeholder="Tell me about your project..."
                    />
                  </div>

                  <Button className="w-full bg-white/20 hover:bg-white/30 border border-white/30 text-white transition-all duration-300">
                    <Send size={16} className="mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info & Social */}
            <div className="space-y-8">
              {/* Contact Information */}
              <Card className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-2xl">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {contactInfo.map((info, index) => {
                    const Icon = info.icon
                    return (
                      <a
                        key={index}
                        href={info.href}
                        className="flex items-center gap-4 p-4 rounded-lg bg-white/10 hover:bg-white/20 transition-colors duration-300"
                      >
                        <div className="p-3 bg-white/20 rounded-full">
                          <Icon size={20} className="text-blue-400" />
                        </div>
                        <div>
                          <div className="font-medium">{info.label}</div>
                          <div className="text-gray-300 text-sm">{info.value}</div>
                        </div>
                      </a>
                    )
                  })}
                </CardContent>
              </Card>

              {/* Social Links */}
              <Card className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-2xl">Connect With Me</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    {socialLinks.map((social, index) => {
                      const Icon = social.icon
                      return (
                        <a
                          key={index}
                          href={social.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`flex flex-col items-center gap-3 p-6 rounded-lg bg-white/10 hover:bg-white/20 transition-all duration-300 text-white/80 ${social.color}`}
                        >
                          <Icon size={32} />
                          <span className="text-sm font-medium">{social.label}</span>
                        </a>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
