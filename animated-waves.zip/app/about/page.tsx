"use client"

import PageLayout from "@/components/PageLayout"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, GraduationCap, Award } from "lucide-react"

export default function AboutPage() {
  const experiences = [
    {
      title: "Senior Full-Stack Developer",
      company: "TechCorp Inc.",
      period: "2022 - Present",
      description: "Leading development of scalable web applications and blockchain integrations.",
    },
    {
      title: "Blockchain Developer",
      company: "CryptoStart",
      period: "2021 - 2022",
      description: "Built DeFi protocols and smart contracts on Ethereum and Polygon networks.",
    },
    {
      title: "Full-Stack Developer",
      company: "WebSolutions",
      period: "2019 - 2021",
      description: "Developed modern web applications using React, Node.js, and cloud technologies.",
    },
  ]

  const education = [
    {
      degree: "Master of Computer Science",
      school: "Stanford University",
      year: "2019",
    },
    {
      degree: "Bachelor of Software Engineering",
      school: "UC Berkeley",
      year: "2017",
    },
  ]

  const certifications = [
    "AWS Certified Solutions Architect",
    "Certified Ethereum Developer",
    "Google Cloud Professional",
    "MongoDB Certified Developer",
  ]

  return (
    <PageLayout>
      <div className="py-32 px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-white mb-6">About Me</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Passionate developer with expertise in modern web technologies and blockchain development. I love creating
              innovative solutions that make a difference.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Experience */}
            <Card className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                  <Calendar className="text-blue-400" size={24} />
                  Experience
                </h2>
                <div className="space-y-6">
                  {experiences.map((exp, index) => (
                    <div key={index} className="border-l-2 border-blue-400/30 pl-4">
                      <h3 className="font-semibold text-lg">{exp.title}</h3>
                      <div className="flex items-center gap-2 text-blue-400 mb-2">
                        <MapPin size={16} />
                        <span>{exp.company}</span>
                        <span>•</span>
                        <span>{exp.period}</span>
                      </div>
                      <p className="text-gray-300 text-sm">{exp.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Education & Certifications */}
            <div className="space-y-8">
              <Card className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
                <CardContent className="p-6">
                  <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                    <GraduationCap className="text-green-400" size={24} />
                    Education
                  </h2>
                  <div className="space-y-4">
                    {education.map((edu, index) => (
                      <div key={index}>
                        <h3 className="font-semibold">{edu.degree}</h3>
                        <p className="text-green-400">{edu.school}</p>
                        <p className="text-gray-400 text-sm">{edu.year}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
                <CardContent className="p-6">
                  <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                    <Award className="text-purple-400" size={24} />
                    Certifications
                  </h2>
                  <div className="flex flex-wrap gap-2">
                    {certifications.map((cert, index) => (
                      <Badge key={index} variant="outline" className="border-purple-400/30 text-purple-400 bg-white/5">
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
