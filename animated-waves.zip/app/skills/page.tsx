"use client"

import PageLayout from "@/components/PageLayout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import CircularProgress from "@/components/CircularProgress"
import { Code, Database, Cloud, Blocks, Smartphone, Palette } from "lucide-react"

export default function SkillsPage() {
  const skillCategories = [
    {
      title: "Frontend Development",
      icon: Code,
      color: "#3b82f6",
      skills: [
        { name: "React/Next.js", level: 95 },
        { name: "TypeScript", level: 90 },
        { name: "Tailwind CSS", level: 85 },
        { name: "Vue.js", level: 80 },
      ],
      technologies: [
        "React",
        "Next.js",
        "Vue.js",
        "TypeScript",
        "JavaScript",
        "HTML5",
        "CSS3",
        "Tailwind",
        "SASS",
        "Webpack",
      ],
    },
    {
      title: "Backend Development",
      icon: Database,
      color: "#10b981",
      skills: [
        { name: "Node.js", level: 92 },
        { name: "Python", level: 88 },
        { name: "PostgreSQL", level: 85 },
        { name: "MongoDB", level: 82 },
      ],
      technologies: [
        "Node.js",
        "Express",
        "Python",
        "Django",
        "FastAPI",
        "PostgreSQL",
        "MongoDB",
        "Redis",
        "GraphQL",
        "REST APIs",
      ],
    },
    {
      title: "Blockchain Development",
      icon: Blocks,
      color: "#8b5cf6",
      skills: [
        { name: "Solidity", level: 88 },
        { name: "Web3.js", level: 85 },
        { name: "Smart Contracts", level: 90 },
        { name: "DeFi Protocols", level: 82 },
      ],
      technologies: [
        "Solidity",
        "Web3.js",
        "Ethers.js",
        "Hardhat",
        "Truffle",
        "IPFS",
        "Ethereum",
        "Polygon",
        "Chainlink",
        "OpenZeppelin",
      ],
    },
    {
      title: "Cloud & DevOps",
      icon: Cloud,
      color: "#f59e0b",
      skills: [
        { name: "AWS", level: 85 },
        { name: "Docker", level: 88 },
        { name: "Kubernetes", level: 75 },
        { name: "CI/CD", level: 82 },
      ],
      technologies: [
        "AWS",
        "Google Cloud",
        "Docker",
        "Kubernetes",
        "Terraform",
        "Jenkins",
        "GitHub Actions",
        "Nginx",
        "Linux",
        "Monitoring",
      ],
    },
    {
      title: "Mobile Development",
      icon: Smartphone,
      color: "#ec4899",
      skills: [
        { name: "React Native", level: 80 },
        { name: "Flutter", level: 75 },
        { name: "iOS/Android", level: 70 },
      ],
      technologies: ["React Native", "Flutter", "Expo", "Swift", "Kotlin", "Firebase", "App Store", "Google Play"],
    },
    {
      title: "Design & Tools",
      icon: Palette,
      color: "#f97316",
      skills: [
        { name: "UI/UX Design", level: 78 },
        { name: "Figma", level: 82 },
        { name: "Git", level: 95 },
      ],
      technologies: ["Figma", "Adobe XD", "Git", "GitHub", "VS Code", "Postman", "Jira", "Slack", "Notion", "Linear"],
    },
  ]

  return (
    <PageLayout>
      <div className="py-32 px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-white mb-6">Skills & Technologies</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              A comprehensive overview of my technical expertise and proficiency levels across various domains.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const Icon = category.icon
              return (
                <Card key={index} className="bg-black/30 border-white/20 text-white backdrop-blur-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="flex items-center gap-3 text-xl">
                      <Icon style={{ color: category.color }} size={24} />
                      <span>{category.title}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    {/* Circular Progress Skills */}
                    <div className="grid grid-cols-2 gap-6">
                      {category.skills.map((skill, skillIndex) => (
                        <CircularProgress
                          key={skillIndex}
                          percentage={skill.level}
                          color={category.color}
                          label={skill.name}
                          size={100}
                          strokeWidth={6}
                        />
                      ))}
                    </div>

                    {/* Technologies */}
                    <div>
                      <h4 className="text-sm font-medium mb-3 text-gray-300">Technologies</h4>
                      <div className="flex flex-wrap gap-2">
                        {category.technologies.map((tech, techIndex) => (
                          <Badge
                            key={techIndex}
                            variant="outline"
                            className="border-white/30 text-white/90 text-xs bg-white/5"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    </PageLayout>
  )
}
